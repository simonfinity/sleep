# then-sleep

Promise-based sleeping.

## Installation

```sh
npm i then-sleep -S
```

## Usage

```js
var sleep = require('then-sleep');

// Sleep for 1 second and do something then.
sleep(1000).then(...);
```

## License

MIT licensed.
